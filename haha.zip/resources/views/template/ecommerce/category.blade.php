
                   

        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" href="#"><i class="fa fa-home"></i>Tất Cả </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#"><i class="fa fa-shopping-bag"></i>Dưỡng Da</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#"><i class="fa fa-plus-square"></i>Thiết Bị Y Tế</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#"><i class="fa fa-female"></i> Đồ Nữ</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#"><i class="fa fa-child"></i>Đồ Nam</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#"><i class="fa fa-tshirt"></i>Quần Áo</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#"><i class="fa fa-mobile-alt"></i>Mỹ Phẩm</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#"><i class="fa fa-microchip"></i>Nước Hoa</a>
            </li>
        </ul>
 