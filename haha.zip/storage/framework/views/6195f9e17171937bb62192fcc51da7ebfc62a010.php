<?php echo $__env->make('template.ecommerce.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <!-- Breadcrumb Start -->
 <div class="breadcrumb-wrap">
    <div class="container-fluid">
        <ul class="breadcrumb">
            <li class="breadcrumb-item"><a href="#">Trang chủ</a></li>
            <li class="breadcrumb-item"><a href="#">Sản Phẩm</a></li>
            <li class="breadcrumb-item active">Đăng nhập & Đăng ký</li>
        </ul>
    </div>
</div>
<!-- Breadcrumb End -->

  <!-- Login Start -->
  <div class="login">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-6"> 
                <form action="<?php echo e(URL::to('/register-user')); ?>" method="post">
                    <?php echo e(csrf_field()); ?>  
                    <?php if($errors->all()): ?> 
                    <ul class="alert text-datger">
                       
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <?php endif; ?>
                <div class="register-form">
                    <div class="row">
                        <div class="col-md-6">
                            <label>Họ và Tên</label>
                            <input required class="form-control" name="name_user"  type="text" placeholder="Tên đầy đủ">
                        </div>
                        <div class="col-md-6">
                            <label>Số điện thoại</label>
                            <input required class="form-control" name="phone_number" type="text" >
                        </div>
                        <div class="col-md-6">
                            <label>Mật khẩu</label>
                            <input required class="form-control"  name="password" type="password" placeholder="Bao gồm chữ và số..">
                        </div>
                        <div class="col-md-6">
                            <label>Nhập lại mật khảu</label>
                            <input required class="form-control" name="re_password" type="password" placeholder="Ít nhất 6 ký tự.">
                        </div>
                        <div class="col-md-12">
                            <button type="submit" class="btn">Đăng ký</button>
                        </div>
                    </div>
                </div>
            </form>   
            </div>
            <div class="col-lg-6">
                <div class="login-form">
                    <form action="<?php echo e(URL::to('/login-user')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-6">
                            <label>Số điện thoại</label>
                            <input required name="phone_number" class="form-control" type="text">
                        </div>
                        <div class="col-md-6">
                            <label>Mật khẩu</label>
                            <input required name="password" class="form-control" type="password" placeholder="Ít nhất 6 ký tự, gồm chữ và số">
                        </div>
                        
                        <div class="col-md-12">
                            <button type="submit" class="btn">Đăng nhập</button>
                        </div>
                    </div>
                </form>
                </div>
                <?php $messFail = Session::get('message');
                    if($messFail){
                 ?>
                <div class="alert alert-danger">
                    
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong>Sai số điện thoại hoặc mật khẩu.</strong>
            </div>
                <?php } Session::put('message',null); ?>
            </div>
        </div>
    </div>
</div>
<!-- Login End -->

<?php echo $__env->make('template.ecommerce.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u876879514/domains/khoecunglea.com/public_html/resources/views/pages/login/login.blade.php ENDPATH**/ ?>