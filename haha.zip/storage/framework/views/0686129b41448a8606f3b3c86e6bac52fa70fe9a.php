<?php echo $__env->make('template.ecommerce.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <!-- Breadcrumb Start -->
 <div class="breadcrumb-wrap">
    <div class="container-fluid">
        <ul class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(URL::to('/trang-chu')); ?>">Trang chủ</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(URL::to('/danh-sach-san-pham')); ?>">Sản phẩm</a></li>
            <li class="breadcrumb-item "><a href="<?php echo e(URL::to('/tra-cuu-don-hang')); ?>">Tra cứu đơn hàng</a></li>
            <li class="breadcrumb-item active">Khách hàng <span class="increment-order-id"><?php echo e($phone); ?></span></li>
        </ul>
    </div>
</div>
<style>
    table {
      font-family: arial, sans-serif;
      border-collapse: collapse;
      width: 100%;
    }
    
    td, th {
      border: 1px solid #dddddd;
      text-align: left;
      padding: 8px;
    }
    
    tr:nth-child(even) {
      background-color: #dddddd;
    }
    </style>
<!-- Breadcrumb End -->
     <!-- Wishlist Start -->
     <div class="wishlist-page">
        <div class="container-fluid">
            <div class="wishlist-page-inner">
                <div class="row">
                    
                    
                    <div class="col-md-12 cart_desktop">
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead class="thead-dark">
                                    <tr>
                                        <th>Mã đơn</th>
                                        <th>Tổng tiền</th>
                                        <th>Trạng thái</th>
                                        <th>Ngày đặt hàng</th>
                                    </tr>
                                </thead>
                                <tbody class="align-middle">
                                   <?php $__currentLoopData = $orderByPhone; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       

                                    <tr>
                                       
                                        <td> <a class="underline" href="<?php echo e(URL::to('theo-doi-don-hang-'.$item->id_order)); ?>"><?php echo e($item->increment_id); ?> </a></td>
                                        <td><?php echo e(number_format( $item->total_order)); ?> đ</td>
                                        
                                        <td><?php echo e($item->status_order); ?></td>
                                        <td><?php echo e($item->created_at); ?></td>
                                   
                                      
                                    </tr>
                               
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                     
                <div id="cart_page" style="margin: 0" ><div class="content_cart_page width_common">
                    <div>
                        <?php if($orderByPhone): ?>
                       
                        <?php $__currentLoopData = $orderByPhone; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <div class="item_cart">
                            <div class="thumb_donhang">
                                <a class="underline" href="<?php echo e(URL::to('theo-doi-don-hang-'.$item->id_order)); ?>"><?php echo e($item->increment_id); ?> </a>
                            </div>
                            <a  href="<?php echo e(URL::to('theo-doi-don-hang-'.$item->id_order)); ?>">
                            <div class="info_donhang">
                                <div class="title_sanpham_donhang space_bottom_5">
                                    <div>
                                        <strong><?php echo e($item->status_order); ?></strong>
                                    </div>
                                    
                                </div>
                                <div class=" space_bottom_5 qty">
                                    <?php echo e(number_format( $item->total_order)); ?> đ
                                
                                </div>
                                <div class="space_bottom_5">
                                    <?php echo e($item->created_at); ?>

                                </div>
                                <span class="txt_color_2 width_common"></span>
                                <span class="txt_color_2 width_common"></span>
                            </div>
                        </a>
                           
                        </div>
                       
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                    </div>
                </div>
            
            </div>
            
                </div>  <div class="cart_desktop"><?php echo e($orderByPhone->links()); ?></div>
                
               
            </div>
            
        </div>
        
    </div>
    <!-- Wishlist End -->
  
<?php echo $__env->make('template.ecommerce.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/u876879514/domains/khoecunglea.com/public_html/resources/views/pages/order/orderByPhone.blade.php ENDPATH**/ ?>