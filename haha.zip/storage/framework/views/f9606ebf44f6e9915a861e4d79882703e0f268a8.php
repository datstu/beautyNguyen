<?php echo $__env->make('template.ecommerce.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
 .cart-btn-lea button, .cart-btn-lea a{
    right: 0;
    position: absolute;
    margin: -45px 0;
    color: #58bd5c;
    background: #ffffff;
    border: 1px solid #58bd5c;
    width: calc(50% - 15px);
    height: 50px;
    padding: 2px 10px;
    text-align: center;
    border-radius: 4px;
    }
.empty-cart-lea a{
    display: block;
    margin: 50px auto;
    width: fit-content;
    border: 1px solid;
    padding: 20px;
    font-weight: 700;
    font-size: larger;
}
.empty-cart-lea a:hover{
    background: #1c8153;
    color: #fff;
}
.txt-center{
    text-align: center;
}
.lea-order{
    margin: 0 auto;
}
.cart-btn-lea a,button:hover{
    background-color: #1baf68;
    font-weight: bold;
    border: #1baf68;
    color: #fff;
}
.cart-content{
    background-color: #fff;
}
</style>
<?php $content = Cart::getContent();?>
            <!-- Cart Start -->
  <div class="cart-page">
   
    <div class="container-fluid">
         <!-- Breadcrumb Start -->
         <div class="breadcrumb-wrap">
            <div class="container-fluid">
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(URL::to('/trang-chu')); ?>">Trang chủ</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(URL::to('danh-sach-san-pham')); ?>">Sản Phẩm</a></li>
                    <li class="breadcrumb-item active">Giỏ hàng</li>
                </ul>
               
            </div>
            
        </div>
        <!-- Breadcrumb End -->
    <?php if(count($content) >0 ): ?>
            <div class="row cart_desktop " style="margin-bottom: 100px;">
                <div class="col-lg-12">  
                    <div class="cart-page-inner">
                        <?php 
                        $mess = Session::get('message'); 
                        if ($mess == 'success_edit') {
                                ?>
                        <div class="alert alert-success">
                                <button type="button" class="close" data-dismiss="alert">×</button>
                                <strong>Cập nhật giỏ hành thành công.</strong>
                        </div>
                        <?php
                        }
                        Session::put('message',null);
                        ?>
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead class="thead-dark">
                                    <tr>
                                        <th width="45%">Sản phẩm </th>
                                        <th width="15%">Giá</th>
                                        <th width="15%">Thành tiền</th>
                                        <th width="15%">Số lượng</th> 
                                        <th width="10%">Xóa</th>
                                    </tr>
                                </thead>
                                <tbody class="align-middle font_family">
                <form action="<?php echo e(URL::to('/update-cart')); ?>" method="POST">  
                    <?php echo e(csrf_field()); ?>   

                <?php $__currentLoopData = $content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
                    <input type="hidden" name="" value="<?php echo e($key); ?>">

                    <tr>
                        <td>
                            <div class="img">
                                <a href="<?php echo e(URL::to('/chi-tiet-san-pham-'.$items->id)); ?>">
                                    <img style="max-height: 80px;min-width: 80px;min-height: 80px;max-width: 80px;" 
                                    src="<?php echo e(asset('public/uploads/product/'.$items->attributes->image)); ?>" alt="<?php echo e($items->name); ?>"></a>
                                <p><?php echo e($items->name); ?></p>
                            </div>
                        </td>
                        <td><?php echo e((number_format($items->price) )); ?> vnđ</td>
                       
                    
                        <input type="hidden" name="form['rowId'][]" value="<?php echo e($key); ?>">

                        <td><?php echo e(number_format($items->getPriceSum())); ?> vnđ</td>
                        <td>
                            <div class="qty">
                                <button type='button' class="btn-minus"><i class="fa fa-minus"></i></button>
                                <input name="arr[<?php echo e($key); ?>][]" type="text" value="<?php echo e($items->quantity); ?>">
                                <button type='button' class="btn-plus"><i class="fa fa-plus"></i></button>
                            </div>
                        </td>
                        <td style="font-size: 26px">
                            <a href="<?php echo e(URL::to('/delete-cart-'.$key)); ?>"><i class="fa fa-trash"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                
                </div>
                
                <div class="col-lg-12">
                    <div class="cart-page-inner">
                        <div class="row">
                            
                            <div class="col-md-12">
                                <div class="cart-summary">
                                    
                                    <div class=" cart-btn-lea">
                                        <button  type="submit" style="right: 0;
                                        position: absolute;margin: -45px 0;">Cập nhật giỏ hàng</button>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            
            </form>
        
         
            <div class="col-md-8 font_family lea-order">
                <div class="cart-summary">
                    <div class="cart-content">
                        <h1 class="txt-center">Hóa đơn của bạn</h1>
                        <p>Tạm tính<span><?php echo e(number_format(Cart::getSubTotal())); ?> vnđ</span></p>
                       
                        <h2 style="font-family: sans-serif;">Tổng cộng<span><?php echo e(number_format(Cart::getTotal())); ?> vnđ</span></h2>
                    </div>
                    <div class="cart-btn-lea">
                        
                        <a href="<?php echo e(URL::to('/checkout')); ?>" class="place_order" style="right: 0;
                        position: absolute;padding: 10px; margin: -28px 200px;">Tiến hành đặt hàng</a>
                    </div>
                </div>
            </div>
           

<!-- Cart End -->
      
          
        <?php else: ?>
        <!-- Breadcrumb Start -->
        <div class="cart_desktop">
         <div class="breadcrumb-wrap ">
            <div class="empty-cart-lea">
                <a href="<?php echo e(URL::to('/danh-sach-san-pham')); ?>">Giỏ hàng đang trống. Tiếp tục mua hàng.</a>
            </div>
        </div>
    </div>
        <!-- Breadcrumb End -->
           
            <?php endif; ?>
            
        </div>

    </div>
    <!-- contact area  END -->
    <?php if(count($content) >0 ): ?>
    
<div id="cart_page" class=""><div class="content_cart_page width_common">
  <div>
    <form action="<?php echo e(URL::to('/update-cart')); ?>" method="POST">  
        <?php echo e(csrf_field()); ?>   

      <?php $__currentLoopData = $content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="item_cart">
          <div class="thumb_donhang">
              <a href="<?php echo e(URL::to('/chi-tiet-san-pham-'.$items->id)); ?>">
                  <img src="<?php echo e(asset('public/uploads/product/'.$items->attributes->image)); ?>" 
                  alt="<?php echo e($items->name); ?>">
              </a>
          </div>
          <div class="info_donhang">
              <div class="title_sanpham_donhang space_bottom_5">
                  <div>
                      <strong><a href="<?php echo e(URL::to('/chi-tiet-san-pham-'.$items->id)); ?>" class="txt_color_1"><?php echo e($items->name); ?></a></strong>
                  </div>
                  
              </div>
              <div class="block_soluong space_bottom_5 qty">
                  <button type='button' class="button_left btn-minus"><i class="icon_minius">&nbsp;</i></button>
                  <input type="text" value="<?php echo e($items->quantity); ?>" name="arr[<?php echo e($key); ?>][]"  class="qty-mobile" id="qty" >
                  <button type='button' class="button_right btn-plus"><i class="icon_plus">&nbsp;</i></button>
              </div>
              <div class="price_cart_info"><span class="number_sl txt_666">x</span>
                  <span class="giamoi"><?php echo e(number_format($items->price)); ?>&nbsp;₫</span>
              </div>
              <span class="txt_color_2 width_common"></span>
              <span class="txt_color_2 width_common"></span>
          </div>
      
          <a href="<?php echo e(URL::to('/delete-cart-'.$key)); ?>" class="btn_del_cart_item material-ripple">
              <img src="<?php echo e(asset('/public/ecommerce/img/cart-mobile/trash_close.svg')); ?>" alt="<?php echo e($items->name); ?>">
          </a>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  
    <div id="box_addcombo_detail" class="width_common box_white border_bottom_detail">
        <div class="block_content_addcombo width_common relative">
            <div class="width_common block_result_addcombo">
                
                    <div class="block_result_combo">
                    <button type="submit" class="btn btn_site_3 btn_site_1" title="Thêm vào giỏ hàng"><span>Cập nhật giỏ hàng</span></button>
                    </div>
               
            </div>
        </div>
    </div>
</form>
  
    <div class="block_total_cart"><div class="total_item space_bottom_10">
        <div class="text_left text_item">Tạm tính:</div>
        <div class="text_right text_item"><div class=""><?php echo e(number_format(Cart::getSubTotal())); ?> &nbsp;₫</div></div></div>
<div class="total_item space_bottom_10">
    <div class="text_left text_item">Tổng thanh toán:</div><div class="text_right text_item">
        <div class="txt_giatien"><?php echo e(number_format(Cart::getTotal())); ?>&nbsp;₫</div>
        <div class="txt_666">Đã bao gồm VAT</div></div></div>
        <div class="text_warning_cart space_bottom_10"><div class="text_right">
            <div class="detail_text_warning_cart"></div></div></div></div></div>
            <div class="clearfix"></div>
            
    <div class="nav_bottom_detail material-ripple">
        <a href="<?php echo e(URL::to('/checkout')); ?>" class="btn btn_site_3">Tiến hành đặt hàng</a>
    </div></div>
    
   
  <!-- Product details -->
  <?php else: ?> 
   <!-- Breadcrumb Start -->
   <div id="cart_page_empty_mobile">
   <div class="breadcrumb-wrap cart_page">
      <div class="empty-cart-lea">
          <a href="<?php echo e(URL::to('/danh-sach-san-pham')); ?>">Giỏ hàng đang trống. Tiếp tục mua hàng.</a>
      </div>
  </div>
</div>
  <!-- Breadcrumb End -->
     
      <?php endif; ?>
</div>

<?php echo $__env->make('template.ecommerce.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/u876879514/domains/khoecunglea.com/public_html/resources/views/pages/cart/show_cart.blade.php ENDPATH**/ ?>