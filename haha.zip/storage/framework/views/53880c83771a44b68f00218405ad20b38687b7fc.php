<?php echo $__env->make('template.ecommerce.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   
    <style>
        @media  only screen and  (max-width: 426px) {
        .bottom-bar {
background: #1baf68;
margin-bottom:unset;
padding:unset;
padding-bottom: 100px;
}}
        </style>    
        <!-- Main Slider Start -->
        <div class="header">
            <div class="container-fluid">
                <div class="row" style="background: #f1f1f5; ">
                    <div class="col-md-3 header-img-mobile">
                        <div class="header-img">
                            <div class="img-item">
                                <img src="<?php echo e(asset('public/ecommerce/img/banner/ban6.jpg')); ?>" />
                                <a class="img-text" >
                                    <p>Lea không chỉ là nơi làm đẹp</p>
                                </a>
                            </div>
                            
                        </div>
                    </div>
                    <style>
                        video {
                            object-fit: fill;
width: 645px;
height: 400px;
display: flex;
}
                    </style>
                    <div class="col-md-6 slider-mobile">
                        <div class="header-slider normal-slider">
                            <div class="header-slider-item">
                                <img  src="<?php echo e(asset('public/ecommerce/img/banner/ban4.jpg')); ?>" alt="Slider Image" />
                               
                            </div>
                            <div class="header-slider-item">
                                <img  src="<?php echo e(asset('public/ecommerce/img/banner/ban5.jpg')); ?>" alt="Slider Image" />
                               
                            </div>
                           
                        </div>
                    </div>
                    <div class="col-md-3 category-desktop">
                        <nav class="navbar bg-light">
                            <?php echo $__env->make('template.ecommerce.category', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </nav>
                    </div>

                   
                    
                </div>
            </div>
        </div>
        
<div class="block_icon_category width_common" id="new_box_icon_category">
    <div class="width_common scroll_horizon">
        <div class="content_scroll_horizon">
            <a href="">
            <div class="new_width_icon_category">
                <div class="item_category_top">
                    <a href="<?php echo e(URL::to('/tra-cuu-don-hang')); ?>" >
                        <span class="icon_lam_category_top">
                            <img src="https://media.hasaki.vn/hsk/icon/menu-category.png"></span>
                            <div class="title_cate_home">Tất cả</div></a><a href="<?php echo e(URL::to('/tra-cuu-don-hang')); ?>"  >
                            <span class="icon_lam_category_top"><img src="<?php echo e(asset('public/ecommerce/img/category-mobile/track-order-70.png')); ?>"></span>
                            <div class="title_cate_home">Tra cứu đơn hàng</div>
                    </a>
                </div>
                <div class="item_category_top">
                    <a href="javascript:;"  onclick="alert('Hệ thống đang cập nhật. Xin cảm ơn.');">
                        <span class="icon_lam_category_top">
                            <img src="<?php echo e(asset('public/ecommerce/img/category-mobile/menu-booking.png')); ?>">
                        </span><div class="title_cate_home">Đặt hẹn</div>
                    </a>
                    <a href="javascript:;"  onclick="alert('Hệ thống đang cập nhật. Xin cảm ơn.');">
                        <span class="icon_lam_category_top">
                            <img src="<?php echo e(asset('public/ecommerce/img/category-mobile/icon-covid.png')); ?>">
                        </span><div class="title_cate_home">Covid</div>
                    </a>
                </div>
                <div class="item_category_top">
                    <a href="javascript:;"  onclick="alert('Hệ thống đang cập nhật. Xin cảm ơn.');"><span class="icon_lam_category_top">
                        <img src="<?php echo e(asset('public/ecommerce/img/category-mobile/now-free-mobile.gif')); ?>"></span>
                        <div class="title_cate_home">Giao 2H</div>
                    </a>
                    <a href="javascript:;"  onclick="alert('Hệ thống đang cập nhật. Xin cảm ơn.');">
                        <span class="icon_lam_category_top"><img src="<?php echo e(asset('public/ecommerce/img/category-mobile/menu-bestseller.png')); ?>"></span>
                        <div class="title_cate_home">Bán chạy</div>
                    </a></div>
                    <div class="item_category_top">
                        <a href="javascript:;"  onclick="alert('Hệ thống đang cập nhật. Xin cảm ơn.');"><span class="icon_lam_category_top"><img src="<?php echo e(asset('public/ecommerce/img/category-mobile/menu-spa.png')); ?>"></span>
                            <div class="title_cate_home">Clinic &amp; S.P.A</div></a>
                            <a href="javascript:;"  onclick="alert('Hệ thống đang cập nhật. Xin cảm ơn.');"><span class="icon_lam_category_top">
                                <img src="<?php echo e(asset('public/ecommerce/img/category-mobile/menu-deals.png')); ?>"></span>
                                <div class="title_cate_home">Deals</div></a></div><div class="item_category_top">
                                    <a href="javascript:;"  onclick="alert('Hệ thống đang cập nhật. Xin cảm ơn.');"><span class="icon_lam_category_top">
                                        <img src="<?php echo e(asset('public/ecommerce/img/category-mobile/menu-spa-services.png')); ?>"></span>
                                        <div class="title_cate_home">Bảng giá</div></a>
                                        <a href="javascript:;"  onclick="alert('Hệ thống đang cập nhật. Xin cảm ơn.');"><span class="icon_lam_category_top">
                                            <img src="<?php echo e(asset('public/ecommerce/img/category-mobile/menu-blog.png')); ?>"></span>
                                            <div class="title_cate_home">Cẩm nang</div></a>
                                        </div>
            </div>
        </div></div>
        </div>
             
        <!-- Main Slider End -->      
        
        <!-- Brand Start -->
       
        <!-- Brand End -->      
        <!-- Featured Product Start -->
        <?php if(count($featureProducts) >3 ): ?>
        <div class="featured-product product"  >
            <div class="container-fluid">
                <div class="section-header">
                    <h2 class="customer-h2">Sản phẩm Nổi bật</h2>
                    
                </div>
                
                    <div class="row align-items-center product-slider ">
                    <?php $__currentLoopData = $featureProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>      
                    <div class="col-lg-3">
                        <div class="product-item">
                            <?php if($item->price_old) {
                                $price = (int)$item->price;
                                $priceOld = (int)$item->price_old;
                                $result =  100 - $price*100 / $priceOld;
                                ?>
                                <div class="label-top ">- <?php echo e(round($result)); ?>%</div>
                                <?php }?>
                            <div class="product-image">
                                <a href="<?php echo e(URL::to('/chi-tiet-san-pham-'.$item->productID)); ?>">
                                    <img class="img-lea"
                                    src="<?php echo e(asset('public/uploads/product/'.$item->image)); ?>" alt="<?php echo e($item->productName); ?>">
                                </a>
                                <div class="product-action">
                                    <form>
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" class="cart_product_id_<?php echo e($item->productID); ?>" value="<?php echo e($item->productID); ?>">
                                        <input type="hidden" class="cart_product_name_<?php echo e($item->productID); ?>" value="<?php echo e($item->productName); ?>">
                                        <input type="hidden" class="cart_product_price_<?php echo e($item->productID); ?>" value="<?php echo e($item->price); ?>">
                                        <input type="hidden" class="cart_product_image_<?php echo e($item->productID); ?>" value="<?php echo e($item->image); ?>">
                                        
                                    <a  class="add-to-cart-lea" data-id_product="<?php echo e($item->productID); ?>"><i class="fa fa-cart-plus"></i></a>
                                </form>
                                    <a href="<?php echo e(URL::to('/chi-tiet-san-pham-'.$item->productID)); ?>"><i class="fa fa-heart"></i></a>
                                    <a href="<?php echo e(URL::to('/chi-tiet-san-pham-'.$item->productID)); ?>"><i class="fa fa-search"></i></a>
                                </div>
                            </div>
                           
                                <!--customer product item-->
                         <a href="<?php echo e(URL::to('/chi-tiet-san-pham-'.$item->productID)); ?>"> 
                            <div class="dez-info p-t20 "> 
                            <div class="m-b15 price"> 
                                <strong class="item_new_price txt_20 left font"><?php echo e($item->price); ?> đ</strong> 
                                <span class="item_old_price txt_20 right font"><?php echo e($item->price_old); ?> ₫</span>
                                                            </div> 
                            <div class="brand_product txt_color_1 ">
                                <div class=" item_name_lea txt_18"><?php echo e($item->productName); ?></div>
                            </div> 
                            <h2 class="  name_product"> 
                                <div class="item_name font">
                                    <?php echo e($item->moTaNgan); ?></div> 
                            </h2> 
                            <div class=" rate font txt_16"> 
                                <div class="block_star start_small"> 
                                    <div style="width:96%;" class="number_start"> </div> 
                                    <div class="start_background"></div> 
                                </div>(56)&nbsp;&nbsp;|&nbsp;&nbsp;<span class="item_count_by txt_16"><img style="width: unset;display: unset; " src="public/frontend/images/css/cart.svg" alt="" draggable="false" class="loading" data-was-processed="true"> 1.581</span>
                            </div>
                        </div>
                        </a>
                                 <!--end customer product item-->
                           
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <!-- Featured Product End -->       
   
        
        <!-- Category Start-->

        <!-- Category End-->       
        
        <!-- Call to Action Start -->
        <div class="call-to-action">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h1 class="customer-h2">Khỏe cùng Lea</h1>
                    </div>
                    <div class="col-md-4" style="text-align: end;">
                        <a href="tel:0907799046">(+84) 090 7799 046</a>
                    </div>
                </div>
            </div>
        </div>
        <!-- Call to Action End -->       
        
        
        
       
        <!-- Newsletter End -->        
        
        <!-- Recent Product Start -->
        <?php if(count($meidcanProducts) >0 ): ?>
        <div class="recent-product product">
            <div class="container-fluid">
                <div class="section-header">
                    <h2 class="customer-h2">Thiết bị Y tế</h2>
            
                    
                </div>
                <div class="row align-items-center product-slider ">
                    <?php $__currentLoopData = $meidcanProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                    
                    <div class="col-lg-3">
                        <div class="product-item">
                            <?php if($item->price_old) {
                                $price = (int)$item->price;
                                $priceOld = (int)$item->price_old;
                                $result =  100 - $price*100 / $priceOld;
                                ?>
                                <div class="label-top ">- <?php echo e(round($result)); ?>%</div>
                                <?php }?>
                            <div class="product-image">
                                <a href="product-detail.html">
                                    <img class="img-lea"
                                    src="<?php echo e(asset('public/uploads/product/'.$item->image)); ?>" alt="<?php echo e($item->productName); ?>">
                                </a>
                                <div class="product-action">
                                    <form>
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" class="cart_product_id_<?php echo e($item->productID); ?>" value="<?php echo e($item->productID); ?>">
                                        <input type="hidden" class="cart_product_name_<?php echo e($item->productID); ?>" value="<?php echo e($item->productName); ?>">
                                        <input type="hidden" class="cart_product_price_<?php echo e($item->productID); ?>" value="<?php echo e($item->price); ?>">
                                        <input type="hidden" class="cart_product_image_<?php echo e($item->productID); ?>" value="<?php echo e($item->image); ?>">

                                    <a  class="add-to-cart-lea" data-id_product="<?php echo e($item->productID); ?>"><i class="fa fa-cart-plus"></i></a>
                                </form>
                                <a href="<?php echo e(URL::to('/chi-tiet-san-pham-'.$item->productID)); ?>"><i class="fa fa-heart"></i></a>
                                    <a href="<?php echo e(URL::to('/chi-tiet-san-pham-'.$item->productID)); ?>"><i class="fa fa-search"></i></a>
                                </div>
                            </div>
                           
                                <!--customer product item-->
                         <a href="<?php echo e(URL::to('/chi-tiet-san-pham-'.$item->productID)); ?>"> 
                            <div class="dez-info p-t20 "> 
                            <div class="m-b15 price"> 
                                <strong class="item_new_price txt_20 left font"><?php echo e($item->price); ?> vnđ</strong> 
                                                            </div> 
                            <div class="brand_product txt_color_1 ">
                                <div class=" item_name_lea txt_18"><?php echo e($item->productName); ?></div>
                            </div> 
                            <h2 class="  name_product"> 
                                <div class="item_name font">
                                    <?php echo e($item->moTaNgan); ?></div> 
                            </h2> 
                            <div class=" rate font txt_16"> 
                                <div class="block_star start_small"> 
                                    <div style="width:96%;" class="number_start"> </div> 
                                    <div class="start_background"></div> 
                                </div>(56)&nbsp;&nbsp;|&nbsp;&nbsp;<span class="item_count_by txt_16"><img style="width: unset;display: unset; " src="public/frontend/images/css/cart.svg" alt="" draggable="false" class="loading" data-was-processed="true"> 1.581</span>
                            </div>
                        </div>
                        </a>
                                 <!--end customer product item-->
                           
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <!-- Recent Product End -->
        
        

        <!-- Review Start -->
      
        <!-- Review End -->        
      
        <?php echo $__env->make('template.ecommerce.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u876879514/domains/khoecunglea.com/public_html/resources/views/pages/product.blade.php ENDPATH**/ ?>