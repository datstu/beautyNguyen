
<?php $__env->startSection('main'); ?>
<style>
.display_block {
    display: block;
}
</style>
<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">Quản lý sản phẩm</h1>
    </div>

</div>
<!--/.row-->
<div class="row">
    <div class="col-xs-12 col-md-12 col-lg-12">
        <div class="panel panel-primary">
            <div class="panel-heading">
                Thêm sản phẩm
            </div>
            <script src="<?php echo e(asset('public/backend/js/number-format/cleave.min.js')); ?>"></script>
            <form name="proForm" onsubmit="return validateForm()" action="<?php echo e(URL::to('/save-product')); ?>" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

<?php if(isset($ProductById) ): ?>

<div class="panel-body">
    <div class="form-group">
        <label>Tên sản phẩm:</label>
        <input value="<?php echo e($ProductById->productName); ?>" type="text" name="nameProduct" class="form-control">
    </div>
    <div class="form-group">
        <label>Mô tả ngắn:</label>
        <input type="text" name="sortDescProduct" class="form-control" value="<?php echo e($ProductById->moTaNgan); ?>" >
    </div>
    <div class="form-group">
        <label>Giá mới:</label>
        <input  type="text"  name="price" class="form-control price_class" value="<?php echo e($ProductById->price); ?>" >
    </div>
    <div class="form-group">
        <label>Giá cũ:</label>
        <input  type="text"  name="priceOld" class="form-control price_class" value="<?php echo e($ProductById->price_old); ?>" >
    </div>
    <div class="form-group">
        <label>Danh mục:</label>
        <select  name="category" class="form-control">
         
            <?php $__currentLoopData = $categoryList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($value->category_id); ?>"
                <?php if($ProductById->catID ==  $value->category_id): ?>
                selected
                <?php endif; ?>
            ><?php echo e($value->category_name); ?></option>
           
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
   
    <div class="form-group">
        <label>Thương hiệu:</label>
        <select  name="brand" class="form-control">
            <?php $__currentLoopData = $brandList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($value->brand_id); ?>"
                <?php if($ProductById->brandID ==  $value->brand_id ): ?>
                selected
                <?php endif; ?>
            ><?php echo e($value->brand_name); ?></option>
           
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
    </div>
    <div class="form-group">
        <label>Miêu tả</label>
        <script  src="<?php echo e(asset('public/backend/ckeditor/ckeditor.js')); ?>"></script>
        <textarea style="resize: none;" row="8" id="ckeditor1235" class="display_block" name="descProduct"><?php echo e($ProductById->product_desc); ?></textarea>
          <script type="text/javascript">
                CKEDITOR.replace('ckeditor1235');
    var editor = CKEDITOR.replace('ckeditor',{
        language:'vi',
        filebrowserImageBrowseUrl: '../../ckfinder/ckfinder.html?Type=Images',
        filebrowserFlashBrowseUrl: '../../ckfinder/ckfinder.html?Type=Flash',
        filebrowserImageUploadUrl: '../../ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images',
        filebrowserFlashUploadUrl: '../../public/backend/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Flash',
    });
</script>
    </div>
    <div class="form-group">
        <label>Ảnh sản phẩm</label>
        <input id="img" type="file" name="imgProductupdate" class="form-control hidden" onchange="changeImg(this)">
        <img id="avatar" class="thumbnail" width="100"
    
        src="<?php echo e(asset('public/uploads/product/'.$ProductById->image)); ?>">
            
       
        
        
    </div>
    <div class="form-group">
        <label>Thuộc tính</label>
        <select  name="typeProduct" class="form-control">
            <?php if($ProductById->type == 0): ?>
            <option selected value="0">None</option>
            <option value="1">Đặc biệt</option>
        <?php else: ?>
            <option value="0">None</option>
            <option selected value="1">Đặc biệt</option>
        <?php endif; ?>
        </select>
    </div>
    <div class="form-group">
        <label>Hiển thị</label>
        <select  name="statusProduct" class="form-control">
            <?php if($ProductById->status == 1): ?>
            <option selected value="1">Hiện</option>
            <option value="0">Ẩn</option>
        <?php else: ?>
            <option value="1">Hiện</option>
            <option selected value="0">Ẩn</option>
        <?php endif; ?>
        </select>
    </div>
    <div class="form-group">
        <label>Từ khóa tìm kiếm:</label>
        <input  type="text" name="meta_keywords" class="form-control" value="<?php echo e($ProductById->meta_keyswords); ?>" >
    </div>
    <div class="form-group ">
        <strong>Tag:</strong>
        <input type="text" data-role="tagsinput" class="form-control" name="tags" value="
        <?php if($ProductById->tags): ?><?php $__currentLoopData = (array)(json_decode($ProductById->tags)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($tag); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php endif; ?>
        ">
      </div>
    <input type="hidden" name="id" value="<?php echo e($ProductById->productID); ?>" >
    <input type="submit" name="submit" value="Cập nhật" class="btn btn-primary">
<?php else: ?>
<div class="panel-body">
    <div class="form-group">
        <label>Tên sản phẩm:</label>
        <input required type="text" name="nameProduct" class="form-control"
            placeholder="Tên sản phẩm...">
    </div>
    <div class="form-group">
        <label>Mô tả ngắn:</label>
        <input required type="text" name="sortDescProduct" class="form-control" >
    </div>
    <div class="form-group">
        <label>Giá mới :</label>
        <input required  type="text"  name="price" class="form-control price_class"  >
    </div>

    <div class="form-group">
        <label>Giá cũ:</label>
        <input required  type="text"  name="priceOld" class="form-control price_class"  >
    </div>

    <div class="form-group">
        <label>Danh mục:</label>
        <select  name="category" class="form-control">
            <?php $__currentLoopData = $categoryList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($value->category_id); ?>"><?php echo e($value->category_name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
   
    <div class="form-group">
        <label>Thương hiệu:</label>
        <select   name="brand" class="form-control">
            <?php $__currentLoopData = $brandList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($value->brand_id); ?>"><?php echo e($value->brand_name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
    </div>
    

    <div class="form-group">
        <label>Mô tả chi tiết</label>
        <script  src="<?php echo e(asset('public/backend/ckeditor/ckeditor.js')); ?>"></script>
        <textarea id="xxx" style="resize: none;" rows="8"  required class="form-control" placeholder="Mô tả sản phẩm" name="descProduct"></textarea>
        <script type="text/javascript">
    var editor = CKEDITOR.replace('xxx');
</script>

    </div>
    <div class="form-group">
        <label>Ảnh sản phẩm</label>
        <input id="img"  type="file" name="imgProduct" class="form-control hidden" onchange="changeImg(this)">
        <img id="avatar" class="thumbnail" width="100"
            src="<?php echo e(asset('public/backend/img/new_seo-10-512.png')); ?>">
    </div>
    <div class="form-group">
        <label>Thuộc tính</label>
        <select  name="typeProduct" class="form-control">
        
            <option selected value="0">None</option>
            <option value="1">Đặc biệt</option>
            <option value="1">Khuyến mãi</option>
            
      
        </select>
    </div>
    <div class="form-group">
        <label>Hiển thị</label>
        <select  name="statusProduct" class="form-control">
            <option value="1">Hiện</option>
            <option value="0">Ẩn</option>

        </select>
    </div>
    <div class="form-group">
        <label>Từ khóa tìm kiếm:</label>
        <input  type="text" name="meta_keywords" class="form-control" >
    </div>
    <div class="form-group ">
        <label for="Tags">Tags:</label>
        <input type="text" data-role="tagsinput" class="form-control" name="tags">
      </div>
    <input type="submit" name="submit" value="Thêm" class="btn btn-primary">
<?php endif; ?>
            
                

                   
                </div>
            </form>
        </div>
    </div>
</div>
<!--/.row-->
<script>document.querySelectorAll('.price_class').forEach(inp => new Cleave(inp, {
    numeral: true,
    numeralThousandsGroupStyle: 'thousand'
  }));

  function validateForm() {
    var x = document.forms["proForm"]["imgProduct"].value;
  if (x == "" || x == null) {
    alert("Vui lòng chọn ảnh.");
    return false;
  }

// var allowedExtension = ['jpeg', 'jpg','png'];
// var fileExtension = document.getElementById('img').value.split('.').pop().toLowerCase();
// var isValidFile = false;
// for(var index in allowedExtension) {

//     if(fileExtension === allowedExtension[index]) {
//         isValidFile = true; 
//         break;
//     }
// }
// if(!isValidFile) {
//     alert('Allowed Extensions are : *.' + allowedExtension.join(', *.'));
// }
// return isValidFile;
}
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u876879514/domains/khoecunglea.com/public_html/resources/views/admin/product/add.blade.php ENDPATH**/ ?>