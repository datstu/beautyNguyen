
<?php $__env->startSection('main'); ?>
<style>
.display_block {
    display: block;
}
</style>
<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">Quản thương hiệu</h1>
    </div>

</div>
<!--/.row-->
<div class="row">
    <div class="col-xs-12 col-md-5 col-lg-5">
        <div class="panel panel-primary">
            <div class="panel-heading">
                Thêm thương hiệu
            </div>
            <form action="<?php echo e(URL::to('/save-brand')); ?>" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

<?php if(isset($brandById) ): ?>

<div class="panel-body">
    <div class="form-group">
        <label>Tên thương hiệu:</label>
        <input value="<?php echo e($brandById->brand_name); ?>" type="text" name="nameBrand" class="form-control">
    </div>
    <div class="form-group">
        <label>Miêu tả</label>
        <textarea class="display_block" name="descBrand"><?php echo e($brandById->brand_desc); ?></textarea>
    </div>
    <div class="form-group">
        <label>Ảnh thương hiệu</label>
        <input id="img" type="file" name="imgBrand" class="form-control hidden" onchange="changeImg(this)">
        <img id="avatar" class="thumbnail" width="100"
        <?php if(empty($brandById->brand_image)): ?>
       
        src="<?php echo e(asset('public/backend/img/new_seo-10-512.png')); ?>">
        <?php else: ?>
        src="<?php echo e(asset('public/uploads/brand/'.$brandById->brand_image)); ?>">
            
        <?php endif; ?>
        
        
    </div>
    <div class="form-group">
        <label>Hiển thị</label>
        <select  name="statusBrand" class="form-control">
        <?php if($brandById->brand_status == 1): ?>
            <option selected value="1">Hiện</option>
            <option value="0">Ẩn</option>
        <?php else: ?>
            <option value="1">Hiện</option>
            <option selected value="0">Ẩn</option>
        <?php endif; ?>
        </select>
    </div>
    <input type="hidden" name="id" value="<?php echo e($brandById->brand_id); ?>" class="btn btn-primary">
    <input type="submit" name="submit" value="Cập nhật" class="btn btn-primary">
<?php else: ?>
<div class="panel-body">
    <div class="form-group">
        <label>Tên thương hiệu:</label>
        <input required="" type="text" name="nameBrand" class="form-control"
            placeholder="Tên danh mục...">
    </div>
    <div class="form-group">
        <label>Miêu tả</label>
        <textarea class="display_block" name="descBrand"></textarea>
    </div>
    <div class="form-group">
        <label>Ảnh thương hiệu</label>
        <input id="img" type="file" name="imgBrand" class="form-control hidden" onchange="changeImg(this)">
        <img id="avatar" class="thumbnail" width="100"
            src="<?php echo e(asset('public/backend/img/new_seo-10-512.png')); ?>">
    </div>
    <div class="form-group">
        <label>Hiển thị</label>
        <select  name="statusBrand" class="form-control">
            <option value="1">Hiện</option>
            <option value="0">Ẩn</option>

        </select>
    </div>
    <input type="submit" name="submit" value="Thêm" class="btn btn-primary">
<?php endif; ?>
            
                

                   
                </div>
            </form>
        </div>
    </div>
</div>
<!--/.row-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u876879514/domains/khoecunglea.com/public_html/resources/views/admin/AddBrand.blade.php ENDPATH**/ ?>