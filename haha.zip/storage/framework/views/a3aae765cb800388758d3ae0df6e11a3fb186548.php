<?php echo $__env->make('template.ecommerce.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <!-- Breadcrumb Start -->
 <div class="breadcrumb-wrap">
    <div class="container-fluid">
        <ul class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(URL::to('/trang-chu')); ?>">Trang chủ</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(URL::to('/danh-sach-san-pham')); ?>">Sản phẩm</a></li>
            <li class="breadcrumb-item "><a href="<?php echo e(URL::to('/tra-cuu-don-hang')); ?>">Tra cứu đơn hàng</a></li>
            <li class="breadcrumb-item active">Đơn hàng <span class="increment-order-id"><?php echo e($orderbyid->increment_id); ?></span></li>
        </ul>
    </div>
</div>
<!-- Breadcrumb End -->
     <!-- Wishlist Start -->
     <div class="wishlist-page">
        <div class="container-fluid">
            <div class="wishlist-page-inner">
                <div class="row">
                    <div class="col-md-8 font_family lea-order">
                        <div class="cart-summary">
                            <div class="cart-content">
                                <p ><span class="info-order-khoe-cung-lea"> Địa chỉ nhận hàng </span><span class="tmp-khoe"> <?php echo e($orderbyid->shipping->address_shipping); ?></span></p>
                                <p ><span class="info-order-khoe-cung-lea tmp-khoe-2"> Số điện thoại người nhận </span><span class="tmp-khoe"> <?php echo e($orderbyid->shipping->phone_shipping); ?></span></p>
                                <p ><span class="info-order-khoe-cung-lea tmp-khoe-2">Phí vận chuyển </span><span class="tmp-khoe"> <?php echo e(number_format($orderbyid->shipping->fee_ship)); ?> đ</span></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 font_family lea-order">
                        <div class="cart-summary">
                            <div class="cart-content">
                                <p ><span class="info-order-khoe-cung-lea  tmp-khoe-2"> Tổng thanh toán </span><span class="tmp-khoe "> <?php echo e(number_format($orderbyid->total_order)); ?> đ</span></p>
                                <p ><span class="info-order-khoe-cung-lea  tmp-khoe-2"> Trạng thái </span><span class="tmp-khoe "> <?php echo e($orderbyid->status_order); ?></span></p>
                                <p ><span class="info-order-khoe-cung-lea  tmp-khoe-2"> Ngày đặt </span><span class="tmp-khoe"> <?php echo e($orderbyid->created_at); ?></span></p>
                              
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 cart_desktop">
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead class="thead-dark">
                                    <tr>
                                        <th>Tên sản phẩm</th>
                                        <th>Giá</th>
                                        <th>Số lượng</th>
                                        <th>Tổng</th>
                                    </tr>
                                </thead>
                                <tbody class="align-middle">
                                    <?php if($productOfOrder): ?>
                                    <?php $__currentLoopData = $orderDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $productOfOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                    <?php if( $order->id_product == $item->productID): ?>
                                    <tr>
                                        <td>
                                            <div class="img">
                                                <a href="<?php echo e(URL::to('/chi-tiet-san-pham-' .$item->productID)); ?>"><img src="<?php echo e(asset('public/uploads/product/'.$item->image)); ?>" alt="<?php echo e($item->productName); ?>"></a>
                                                <p><?php echo e($item->productName); ?></p>
                                            </div>
                                        </td>
                                        <td><?php echo e($item->price); ?> đ</td>
                                     
                                        <td>
                                            <?php echo e($order->sales_qty); ?>

                                        </td>
                                        <td>
                                            <?php echo e(number_format( $order->sub_total)); ?>

                                        </td>
                                       
                                      
                                    </tr>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                <div id="cart_page" class=""><div class="content_cart_page width_common">
                        <div>
                            <?php if($productOfOrder): ?>
                            <?php $__currentLoopData = $orderDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $productOfOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if( $order->id_product == $item->productID): ?>
                         
                            <div class="item_cart">
                                <div class="thumb_donhang">
                                    <a href="<?php echo e(URL::to('/chi-tiet-san-pham-' .$item->productID)); ?>">
                                        <img src="<?php echo e(asset('public/uploads/product/'.$item->image)); ?>" 
                                        alt="<?php echo e($item->productName); ?>">
                                    </a>
                                </div>
                                <div class="info_donhang">
                                    <div class="title_sanpham_donhang space_bottom_5">
                                        <div>
                                            <strong><a href="<?php echo e(URL::to('/chi-tiet-san-pham-' )); ?>" class="txt_color_1"><?php echo e($item->productName); ?></a></strong>
                                        </div>
                                        
                                    </div>
                                    <div class="block_soluong space_bottom_5 qty">
                                       
                                    <input type="text" value="123" name="arr[123][]"  class="qty-mobile" id="qty" >
                                       
                                    </div>
                                    <div class="price_cart_info"><span class="number_sl txt_666">x</span>
                                        <span class="giamoi"><?php echo e(($item->price)); ?>&nbsp;₫</span>
                                    </div>
                                    <span class="txt_color_2 width_common"></span>
                                    <span class="txt_color_2 width_common"></span>
                                </div>
                            
                               
                            </div>
                            <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                        </div>
                    </div>
                
                </div>
                
            
        </div>
        
    </div>
    <!-- Wishlist End -->
  
<?php echo $__env->make('template.ecommerce.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/u876879514/domains/khoecunglea.com/public_html/resources/views/pages/order/detailOrder.blade.php ENDPATH**/ ?>