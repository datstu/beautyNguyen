<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Gửi mail google</title>
</head>
<body>
    <h1>Kiểm tra đơn hàng: <span style="color: red"><?php echo e($id); ?></span> </h1>
    <h4>Đường dẫn để xem đơn hàng:  <?php echo e($link); ?></h4>
</body>
</html><?php /**PATH /home/u876879514/domains/khoecunglea.com/public_html/resources/views/pages/mail.blade.php ENDPATH**/ ?>