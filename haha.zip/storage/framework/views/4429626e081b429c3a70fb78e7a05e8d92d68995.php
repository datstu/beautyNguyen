
<?php $__env->startSection('main'); ?>

<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">Quản lý sản phẩm</h1>
    </div>

</div>
<!--/.row-->
<style>
    
    .them-anh-lea-a{
        margin: 5px;background: green;
        border: 0;
    }
</style>
<div class="row">
    <div class="col-xs-12 col-md-12 col-lg-12">
<?php

$message = Session::get('message');
     
$data = [[
    'mess'=>'success_add',
    'class'=>'alert-success',
    'status'=>'Successfully!',
    'value'=>'Thêm sản phẩm thành công.'
    ],
    [
        'mess'=>'fail_add',
        'class'=>'alert-danger',
        'status'=>'Error!',
        'value'=>'Đã xảy ra lỗi khi thêm sản phẩm.'
    ],
    [
    'mess'=>'success_edit',
    'class'=>'alert-success',
    'status'=>'Successfully!',
    'value'=>'Cập nhật sản phẩm thành công.'
    ],
    [
    'mess'=>'fail_edit',
    'class'=>'alert-danger',
    'status'=>'Error!',
    'value'=>'Đã xảy ra lỗi khi cập nhật sản phẩm.'
    ],
    [
    'mess'=>'success_delete',
    'class'=>'alert-success',
    'status'=>'Successfully!',
    'value'=>'Đã xóa 1 sản phẩm.'
    ],
    [
    'mess'=>'fail_delete',
    'class'=>'alert-danger',
    'status'=>'Error!',
    'value'=>'Đã xảy ra lỗi khi xóa 1 sản phẩm.'
]];
?>

<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
     <?php if( $message == $value['mess']): ?>
     <div class="alert <?php echo e($value['class']); ?>">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong><?php echo e($value['status']); ?></strong> <?php echo e($value['value']); ?>

    </div>
    <?php Session::put('message',null); ?>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="panel panel-primary">
            <div class="panel-heading">Quản lý sản phẩm</div>
            <div class="panel-body">
                <div class="bootstrap-table">
                    <div class="table-responsive">
                        <a href="<?php echo e(URL::to('/them-san-pham')); ?>" class="btn btn-primary">Thêm sản phẩm</a>
                        <table class="table table-bordered" style="margin-top:20px;">
                            <thead>
                                <tr class="bg-primary">
                                    <th>ID</th>
                                    <th>Tên sản phẩm</th>
                                    <th width="300">Mô tả ngắn</th>
                                    <th width="200">Ảnh chính </th>
                                    <th>Hiển thị</th>
                                    <th  width="200">Tùy chọn</th>
                                </tr>
                            </thead>
                            <tbody>
<?php $__currentLoopData = $listProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($product->productID); ?></td>
        <td><?php echo e($product->productName); ?></td>
        
        <td><?php echo e($product->moTaNgan); ?></td>
        <td>
            <img width="200px"
                src="<?php echo e(asset('public/uploads/product/'.$product->image)); ?>"
                class="thumbnail">
        </td>
        <td>
            <?php if($product->status == 1): ?>
            Hiển thị
            <?php else: ?>
            Ẩn
            <?php endif; ?>
        </td>
        <td>
            <a href="<?php echo e(URL::to('/cap-nhat-san-pham/'.$product->productID)); ?>" class="btn btn-warning"><i class="fa fa-pencil"
                    aria-hidden="true"></i> Sửa</a>
            <a onclick="return confirm('Bạn muốn xóa danh mục <?php echo e($product->productName); ?>?')" href="<?php echo e(URL::to('/xoa-san-pham/'.$product->productID )); ?>" class="btn btn-danger"><i class="fa fa-trash"
                    aria-hidden="true"></i> Xóa</a>
            <a href="<?php echo e(URL::to('/them-anh-'.$product->productID )); ?>" class="btn btn-danger them-anh-lea-a"><i class="fa fa-trash"
                aria-hidden="true"></i> Thêm ảnh</a>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>						
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="clearfix"></div>
                <?php echo e($listProduct->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u876879514/domains/khoecunglea.com/public_html/resources/views/admin/product/list.blade.php ENDPATH**/ ?>