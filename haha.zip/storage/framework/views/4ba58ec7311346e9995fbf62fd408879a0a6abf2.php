
<?php $__env->startSection('main'); ?>
<style>
.display_block {
    display: block;
}
</style>
<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">Quản lý danh mục</h1>
    </div>

</div>
<!--/.row-->
<div class="row">
    <div class="col-xs-12 col-md-5 col-lg-5">
        <div class="panel panel-primary">
            <div class="panel-heading">
                Thêm danh mục
            </div>
            <form action="<?php echo e(URL::to('/save-category')); ?>" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

<?php if(isset($categoryById) ): ?>

<div class="panel-body">
    <div class="form-group">
        <label>Tên danh mục:</label>
        <input value="<?php echo e($categoryById->category_name); ?>" type="text" name="nameCategory" class="form-control">
    </div>
    <div class="form-group">
        <label>Miêu tả</label>
        <textarea class="display_block" name="descCategory"><?php echo e($categoryById->category_desc); ?></textarea>
    </div>
    <div class="form-group">
        <label>Ảnh sản phẩm</label>
        <input id="img" type="file" name="imgCategory" class="form-control hidden" onchange="changeImg(this)">
        <img id="avatar" class="thumbnail" width="100"
        <?php if(empty($categoryById->category_image)): ?>
       
        src="<?php echo e(asset('public/backend/img/new_seo-10-512.png')); ?>">
        <?php else: ?>
        src="<?php echo e(asset('public/uploads/category/'.$categoryById->category_image)); ?>">
            
        <?php endif; ?>
        
        
    </div>
    <div class="form-group">
        <label>Hiển thị</label>
        <select  name="statusCategory" class="form-control">
        <?php if($categoryById->category_status == 1): ?>
            <option selected value="1">Hiện</option>
            <option value="0">Ẩn</option>
        <?php else: ?>
            <option value="1">Hiện</option>
            <option selected value="0">Ẩn</option>
        <?php endif; ?>
        </select>
    </div>
    <input type="hidden" name="id" value="<?php echo e($categoryById->category_id); ?>" class="btn btn-primary">
    <input type="submit" name="submit" value="Cập nhật" class="btn btn-primary">
<?php else: ?>
<div class="panel-body">
    <div class="form-group">
        <label>Tên danh mục:</label>
        <input required="" type="text" name="nameCategory" class="form-control"
            placeholder="Tên danh mục...">
    </div>
    <div class="form-group">
        <label>Miêu tả</label>
        <textarea class="display_block" name="descCategory"></textarea>
    </div>
    <div class="form-group">
        <label>Ảnh sản phẩm</label>
        <input id="img" type="file" name="imgCategory" class="form-control hidden" onchange="changeImg(this)">
        <img id="avatar" class="thumbnail" width="100"
            src="<?php echo e(asset('public/backend/img/new_seo-10-512.png')); ?>">
    </div>
    <div class="form-group">
        <label>Hiển thị</label>
        <select  name="statusCategory" class="form-control">
            <option value="1">Hiện</option>
            <option value="0">Ẩn</option>

        </select>
    </div>
    <input type="submit" name="submit" value="Thêm" class="btn btn-primary">
<?php endif; ?>
            
                

                   
                </div>
            </form>
        </div>
    </div>
</div>
<!--/.row-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u876879514/domains/khoecunglea.com/public_html/resources/views/admin/AddCategory.blade.php ENDPATH**/ ?>