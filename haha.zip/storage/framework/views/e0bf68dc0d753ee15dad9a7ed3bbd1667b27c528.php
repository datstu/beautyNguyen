
<?php $__env->startSection('main'); ?>
<style>
.display_block {
    display: block;
}
</style>
<div class="row">
    <div class="col-lg-12">
        <h3 class="page-header">Thêm nhiều ảnh cho sản phẩm: </h3>
    </div>

</div>
<!--/.row-->
<?php
$message = Session::get('message');
     
$data = [[
    'mess'=>'success_add',
    'class'=>'alert-success',
    'status'=>'Successfully!',
    'value'=>'Thêm ảnh mới thành công.'
    ],
    [
        'mess'=>'fail_add',
        'class'=>'alert-danger',
        'status'=>'Error!',
        'value'=>'Đã xảy ra lỗi khi thêm ảnh.'
    ],
    [
    'mess'=>'success_delete',
    'class'=>'alert-success',
    'status'=>'Successfully!',
    'value'=>'Xóa ảnh thành công.'
    ],
    [
    'mess'=>'fail_delete',
    'class'=>'alert-danger',
    'status'=>'Error!',
    'value'=>'Xóa ảnh thất bại.'
]];
?>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
<?php if( $message == $value['mess']): ?>
<div class="alert <?php echo e($value['class']); ?>">
   <button type="button" class="close" data-dismiss="alert">×</button>
   <strong><?php echo e($value['status']); ?></strong> <?php echo e($value['value']); ?>

</div>
<?php Session::put('message',null); ?>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="row">
    <div class="col-xs-12  ">
        <div class="panel panel-primary">
            <div class="panel-heading">
              <?php echo e($productDetail->productName); ?>

            </div>

        <div class="col-xs-5 panel-body">  
            <form enctype="multipart/form-data" action="<?php echo e(URL::to('/save-multi-image')); ?>"   method="post" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

            <div class="form-group">
                
                 <input required multiple="multiple" type="file" name="imgMulti[]" class="form-control " onchange="changeImg(this)"> 
              
            </div>
            <input type="hidden" name="productId" value="<?php echo e($productDetail->productID); ?>">
            <input type="submit" name="submit" value="Thêm" class="btn btn-primary">
            </form>
    </div>
           <div class="panel panel-primary">
          
            <div class="panel-body">
                <div class="bootstrap-table">
                    <div class="table-responsive">
                        
                        <table class="table table-bordered" style="margin-top:20px;">
                            <thead>
                                <tr class="bg-primary">
                                    <th>ID</th>
                                    <th width="200px">Hình</th>
                                    
                                    <th>Tùy chọn</th>
                                </tr>
                            </thead>
        <tbody>
<?php $__currentLoopData = $listImgaOfProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imgae): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($imgae->imgID); ?></td>
        <td> <img width="200"
            src="<?php echo e(asset('public/uploads/product/'.$imgae->imgName)); ?>"
            class="thumbnail"></td>
        
       
       
        <td>
            <a onclick="return confirm('Bạn có chắn muốn xóa?')" href="<?php echo e(URL::to('/delete-multi-image-'.$imgae->imgID)); ?>" class="btn btn-danger"><i class="fa fa-trash"
                    aria-hidden="true"></i> Xóa</a>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="clearfix"></div>
                <?php echo e($listImgaOfProduct->links()); ?>

            </div>
        </div>
        </div>
    </div>
</div>
<!--/.row-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u876879514/domains/khoecunglea.com/public_html/resources/views/admin/multiImage/show.blade.php ENDPATH**/ ?>