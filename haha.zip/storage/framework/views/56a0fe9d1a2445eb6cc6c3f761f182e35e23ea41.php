
<?php $__env->startSection('main'); ?>		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Trang chủ</h1>
			</div>
		</div><!--/.row-->
									
		<div class="row">
			<div class="col-xs-12 col-md-6 col-lg-3">
				<div class="panel panel-blue panel-widget ">
					<div class="row no-padding">
						<div class="col-sm-3 col-lg-5 widget-left">
							<svg class="glyph stroked bag"><use xlink:href="#stroked-bag"></use></svg>
						</div>
						<div class="col-sm-9 col-lg-7 widget-right">
							<div class="large"><?php echo e($countProduct); ?></div>
							<div class="text-muted">Sản phẩm</div>
						</div>
					</div>
				</div>
			</div>
			
			
			
		</div><!--/.row-->
		<div class="row">
			<h3>Thống kê truy cập</h3>
			<table class="table">
				<thead>
				  <tr>
					<th scope="col">Đang Online</th>
					<th scope="col">Tổng tháng trước</th>
					<th scope="col">Tổng tháng này</th>
					<th scope="col">Tổng 1 năm</th>
					<th scope="col">Tổng truy cập</th>
				  </tr>
				</thead>
				<tbody>
				  <tr>
					<th scope="row"><?php echo e($visitorOnline); ?></th>
					<td><?php echo e($visitorLastmonthCount); ?></td>
					<td><?php echo e($visitorThismonthCount); ?></td>
					<td><?php echo e($visitorOneYearsCount); ?></td>
					<td><?php echo e($visitorTotal); ?></td>
				  </tr>
				  
				  </tr>
				</tbody>
			  </table>
		</div>
		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u876879514/domains/khoecunglea.com/public_html/resources/views/admin/Dashboard.blade.php ENDPATH**/ ?>